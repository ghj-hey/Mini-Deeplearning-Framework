## About

This Haojie Guo's Deeplearning Framework!

## Feature

* Define Dynamic Computing Graph
* Define Neural Network Operator
* Define Linear, Sigmoid, L2_loss
* Auto-Diff Computing
* Auto-Feedforward and Backward Propogation

## Remain

* Classification
* Cross-Entropy
* CNN, RNN

## Connection

wechat: GHJ2739475149
Mail: ghj_xin@163.com